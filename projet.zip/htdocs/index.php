<!DOCTYPE html>
<html>

<head>
	<title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="./index/index2.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
</head>

<body>
	
	<div id="enTete">
		<h1>Veuillez entrer vos identifiants</h1>
		
		<form action="index.php" method="get">
			<input type="text" name="identifiant" id="id1" placeholder="Entrez votre identifiant"/><br/>
            <input type="password" name="mdp" id="id2" placeholder="Entrez votre mot de passe"/><br/>
            <button name="realinsc" id="id3"><i class="fas fa-user-tie"></i> S'inscrire</button>
			<button type="submit"><i class="fas fa-check"></i> Confirmer la connexion</button>
		</form>
		
	
	</div>
	
	<div id="corps">
		
		<?php
			
			// Teste la connexion MySQL
			$connSQL = new mysqli('db4free.net', 'mbm_user', 'azertyuiop', 'mbm_db');
			if ($connSQL->connect_error)
			{
				die("Erreur de la connexion à la base MySQL: " . $conn->connect_error);
			}
			else
			{
				//Il y a une recherche
				if(isset($_GET["recherche"]) )
				{
					$nomRecherche = str_replace("+"," ",$_GET["recherche"]);
					$sql = "SELECT * FROM ListeMeme WHERE Nom LIKE '%" .$nomRecherche  ."%' ORDER BY id DESC;";
				}
				//Pas de recherche
				else
				{
					$sql = "SELECT * FROM ListeMeme ORDER BY id DESC;";
				}
				
				$result = $connSQL->query($sql);
				//Résultat
				if ($result->num_rows > 0)
				{
					//Lecture du même
					while($row = $result->fetch_assoc())
					{
						$nomMeme = str_replace("§", " ", $row["Nom"]);
						
						echo "<h2>" .$nomMeme ."</h2>";
						echo "<a href='meme.php?id=" .$row["id"] ."'><img src='http://meme-bullshit-meter.rf.gd/memeImage/" .$row["ImageURL"] ."' alt='" .$row["Nom"] ."'></a><br/>";
						echo $row["Vu"] ." Vues";
						echo " / Posté le : " .$row["Date"];
					}
				}
				else
				{
					die("Erreur : Aucun Meme ne correspond à votre recherche");
				}
				
				// Fermeture de la connexion
				$connSQL->close();
			}
		?>
	</div>
	
</body>

