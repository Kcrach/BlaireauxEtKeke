var sel=document.getElementById("selection");
sel2=document.getElementById(selection2);
var ch=document.getElementById("choix");
var tableau =[
	["Chaussettes", "Chat", "10"],
	["Chaussures","Bottines","10"],
	["Pull","Laine","10"]
];
window.onload = function tristanledieu(){

for(var f=0 ; f<tableau.length ; f++){

		//rough elements
		var tr = document.createElement('tr');
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		var opt = document.createElement('option');
		var text1 = document.createTextNode(""+tableau[f][0]);
		opt.appendChild(text1);
	for(var i=0 ; i<tableau[f].length ; i++){
		//text nodes
		var text = document.createTextNode(""+tableau[f][i]);
		if(i==0){
			td1.appendChild(text);
		}
		if(i==1){
			td2.appendChild(text);
		}
		if(i==2){
			td3.appendChild(text);
		}

	}
	//new row in tab
	tr.appendChild(td1);
	tr.appendChild(td2);
	tr.appendChild(td3);
	sel.appendChild(opt);
	ch.appendChild(tr);
}}
function changecat(){
	var catact=sel.selectedIndex.value;
	for(f=0;f<tableau.length ; f++){
		if (tableau[f][0]==catact){
			var opt1= document.createElement("option");
			var text2=document.createTextNode(""+tableau[f][1]);
			opt1.appendChild(text2);
			ch.appendChild(opt1);
		}
	}

}